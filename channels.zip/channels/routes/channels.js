(function() {
    "use strict";

    const express = require("express");

    const Controller = require("../controllers/channels");

    let router = new express();

    router.get('/', (req,res) => (new Controller(req,res)).index());
    router.post('/', (req,res) => (new Controller(req,res)).createChannel());
    router.get('/list' , (req, res) => (new Controller(req,res)).listChannels());
    router.get('/:id', (req,res) => (new Controller(req,res)).getChannel());
    router.put('/:id', (req,res) => (new Controller(req,res)).updateChannel());
    router.delete('/:id', (req,res) => (new Controller(req,res)).deleteChannel());

    module.exports = router;

})();