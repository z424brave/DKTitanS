(function(){
    "use strict";

    const Globals = require("../core/titan_global");
    const TitanInitBase = require(`${Globals.CORE}/titan_init_base`);
    const Logger = require(`${Globals.COMMON}/logger`);
    const Modules = require(`${Globals.CORE}/titan_modules`);

    class ChannelsInit extends TitanInitBase {

        constructor() {
            super();
        }

        init() {
            Logger.info("Starting Channels");
        }
    }

    module.exports = ChannelsInit;

})();